# Слайдер первого экрана — 2 новых фото

Первое фото слайдера уже есть (hero.jpg). Нужны ещё два. Формат **16:9, 2560×1440**, JPG.
Левая треть кадра должна быть спокойной: поверх неё лежит светлая плашка с текстом.

## Общая часть (добавлять в конец каждого промпта)
```
Same visual style as ref-style-hero.jpg: soft natural daylight, warm cream and honey-wood tones, gentle soft shadows, light, airy and cozy atmosphere, editorial hotel photography, wide-angle 24-28mm, realistic, high resolution. Keep the real interior from the reference (layout, furniture, materials) — this is a real hotel, do not invent architecture. Keep the left third of the frame calm and uncluttered for a text panel. No people, no text, no logos, no watermark.
```
Негативный промпт: `dark, gloomy, cold blue tones, harsh flash, oversaturated, HDR look, CGI, distorted furniture, warped lines, text, watermark`

## hero-2.jpg — зал ресторана «Берёзки»
Референсы: `ref-restaurant-hall-old.webp` (реальный зал, планировка), `ref-restaurant-style.jpg` (стиль и свет)
```
Wide interior shot of the hotel restaurant hall from the reference: rows of tables with chairs, pendant lamps, large windows along the wall, green plants, served tables with white plates and glasses. Late morning sunlight through the windows, warm and inviting, calm atmosphere before guests arrive.
```

## hero-3.jpg — лобби
Референсы: `ref-lobby-old.jpg` (реальное лобби), `ref-lobby-style.jpg` (стиль и свет)
```
Wide shot of the hotel lobby from the reference: dark wall with a geometric wood relief, patterned stone floor, a brass luggage cart and a large potted plant, soft seating area, warm table lamps. Evening golden light, welcoming and cozy, feeling of arrival.
```
