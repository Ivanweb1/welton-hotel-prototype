# Слайдер «Бассейн, сауна и тренажёрный зал» — 2 новых фото

Первое фото есть (pool.jpg). Нужны ещё два. Формат **1:1, 1400×1400**, JPG.

Важно: реальных фото сауны и тренажёрного зала у нас нет. Лучше всего взять их с Яндекс Карт отеля (там 562 фото) и использовать как основной референс, а `ref-style-pool.jpg` — как референс стиля. Без реального фото генератор придумает интерьер, которого в отеле нет.

## Общая часть (добавлять в конец каждого промпта)
```
Same visual style as ref-style-pool.jpg: soft warm light, cream and honey-wood tones, gentle shadows, clean, calm and cozy spa atmosphere, editorial hotel photography, realistic, high detail. If a real photo of the room is attached, keep its layout, equipment and materials exactly. Square composition. No people, no text, no logos, no watermark.
```
Негативный промпт: `dark, gloomy, cold blue tones, harsh flash, oversaturated, HDR look, CGI, distorted lines, text, watermark`

## spa-sauna.jpg — финская сауна
```
Interior of a Finnish sauna in a hotel spa: warm light wooden benches on two levels, wooden wall panels, a sauna heater with stones, a wooden bucket and ladle, soft warm hidden lighting under the benches, a folded white towel on the bench. Warm, relaxing, clean.
```

## spa-gym.jpg — тренажёрный зал
```
Bright hotel gym: cardio machines (treadmill, elliptical) and a rack of dumbbells, light wooden floor, large window with daylight, a green plant in the corner, a stack of fresh white towels. Fresh, energetic but calm, very clean.
```
